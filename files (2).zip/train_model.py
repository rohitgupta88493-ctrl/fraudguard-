"""
train_model.py — FraudGuard ML Model Training Script
=====================================================
Downloads and trains a Gradient Boosting classifier on the
Kaggle Credit Card Fraud dataset.

Steps:
  1. pip install -r requirements.txt
  2. Download creditcard.csv from:
     https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud
  3. Place it in: ml-service/data/creditcard.csv
  4. Run: python train_model.py

Output:
  models/fraud_model.pkl  — trained classifier
  models/scaler.pkl       — StandardScaler for Amount feature
"""

import os
import pickle
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report, roc_auc_score, confusion_matrix
)

try:
    from imblearn.over_sampling import SMOTE
    HAS_SMOTE = True
except ImportError:
    HAS_SMOTE = False
    print("⚠️  imbalanced-learn not installed — skipping SMOTE. Run: pip install imbalanced-learn")

os.makedirs("models", exist_ok=True)
os.makedirs("data", exist_ok=True)

DATA_PATH = "data/creditcard.csv"
MODEL_PATH = "models/fraud_model.pkl"
SCALER_PATH = "models/scaler.pkl"

def main():
    if not os.path.exists(DATA_PATH):
        print(f"❌ Dataset not found at {DATA_PATH}")
        print("Download from: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud")
        return

    print("📊 Loading dataset...")
    df = pd.read_csv(DATA_PATH)
    print(f"   Shape: {df.shape}")
    print(f"   Fraud rate: {df['Class'].mean():.4%}")

    X = df.drop(["Class", "Time"], axis=1)
    y = df["Class"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train["Amount"] = scaler.fit_transform(X_train[["Amount"]])
    X_test["Amount"] = scaler.transform(X_test[["Amount"]])

    if HAS_SMOTE:
        print("⚖️  Applying SMOTE for class balancing...")
        smote = SMOTE(random_state=42)
        X_res, y_res = smote.fit_resample(X_train, y_train)
    else:
        X_res, y_res = X_train, y_train

    print("🧠 Training Gradient Boosting model...")
    model = GradientBoostingClassifier(
        n_estimators=200,
        learning_rate=0.1,
        max_depth=4,
        subsample=0.8,
        random_state=42,
        verbose=1,
    )
    model.fit(X_res, y_res)

    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    print("\n📈 Model Performance:")
    print(classification_report(y_test, y_pred, target_names=["Legitimate", "Fraud"]))
    print(f"AUC-ROC: {roc_auc_score(y_test, y_proba):.4f}")
    cm = confusion_matrix(y_test, y_pred)
    print(f"Confusion Matrix:\n{cm}")

    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    with open(SCALER_PATH, "wb") as f:
        pickle.dump(scaler, f)

    print(f"\n✅ Model saved → {MODEL_PATH}")
    print(f"✅ Scaler saved → {SCALER_PATH}")
    print("\n🚀 Start the ML service: uvicorn ml_service:app --reload")

if __name__ == "__main__":
    main()
